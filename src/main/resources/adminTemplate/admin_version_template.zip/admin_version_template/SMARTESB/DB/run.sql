select sysdate from dual;
