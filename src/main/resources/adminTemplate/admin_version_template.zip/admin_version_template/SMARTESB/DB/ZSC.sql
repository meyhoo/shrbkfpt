

use hopesb;

source ./SCRIPT/protocol-zsc.sql;