﻿delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_proxy_payRecharge';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_proxy_payWithdraw';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_proxy_queryAccountNo';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_querySignContract';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_signContractPayApply';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_signContractPay';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_cashierRecharge';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_cashierWithdraw';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_orderPayment';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_proxy_orderPayment';
DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_cmp_orderPre';
DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_cmp_bizOrderQuery';
DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_cmp_maintainSignInfo';
DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_proxy_signContract';
DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_cmp_commonVerifyFace';


delete from  hopesb.services   where name =  'commonVerifyFace_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'commonVerifyFace_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'commonVerifyFace_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'commonVerifyFace_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'commonVerifyFace_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_commonVerifyFace' and location='local_out' and stype='SERVICE' and SERVICEID='commonVerifyFace_napi';


# 'payRecharge_sdk'
delete from  hopesb.services   where name =  'payRecharge_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'payRecharge_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'payRecharge_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'payRecharge_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'payRecharge_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_payRecharge' and location='local_out' and stype='SERVICE' and SERVICEID='payRecharge_sdk';
# 'checkPayPassWord_napi'
delete from  hopesb.services   where name =  'checkPayPassWord_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'checkPayPassWord_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'checkPayPassWord_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'checkPayPassWord_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'checkPayPassWord_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_checkPayPassWord' and location='local_out' and stype='SERVICE' and SERVICEID='checkPayPassWord_napi';
# 'payWithdraw_sdk'
delete from  hopesb.services   where name =  'payWithdraw_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'payWithdraw_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'payWithdraw_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'payWithdraw_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'payWithdraw_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_proxy_payWithdraw' and location='local_out' and stype='SERVICE' and SERVICEID='payWithdraw_sdk';
# 'queryAcctBlance_sdk'
delete from  hopesb.services   where name =  'queryAcctBlance_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'queryAcctBlance_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'queryAcctBlance_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'queryAcctBlance_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'queryAcctBlance_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_queryCustAcctBalance' and location='local_out' and stype='SERVICE' and SERVICEID='queryAcctBlance_sdk';

# 'getTransactionList_sdk'
delete from  hopesb.services   where name =  'getTransactionList_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'getTransactionList_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'getTransactionList_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'getTransactionList_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'getTransactionList_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_getTransactionList' and location='local_out' and stype='SERVICE' and SERVICEID='getTransactionList_sdk';

# 'queryAccountNo_sdk'
delete from  hopesb.services   where name =  'queryAccountNo_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'queryAccountNo_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'queryAccountNo_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'queryAccountNo_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'queryAccountNo_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_proxy_queryAccountNo' and location='local_out' and stype='SERVICE' and SERVICEID='queryAccountNo_sdk';

delete from  hopesb.services   where name =  'rechargeSendMsg_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'rechargeSendMsg_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'rechargeSendMsg_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'rechargeSendMsg_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'rechargeSendMsg_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_rechargeSendMsg' and location='local_out' and stype='SERVICE' and SERVICEID='rechargeSendMsg_sdk';

delete from  hopesb.services   where name =  'querySignContract_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'querySignContract_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'querySignContract_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'querySignContract_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'querySignContract_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_querySignContract' and location='local_out' and stype='SERVICE' and SERVICEID='querySignContract_sdk';

delete from  hopesb.services   where name =  'signContractPayApply_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'signContractPayApply_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'signContractPayApply_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'signContractPayApply_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'signContractPayApply_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_signContractPayApply' and location='local_out' and stype='SERVICE' and SERVICEID='signContractPayApply_sdk';

delete from  hopesb.services   where name =  'signContractPay_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'signContractPay_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'signContractPay_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'signContractPay_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'signContractPay_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_signContractPay' and location='local_out' and stype='SERVICE' and SERVICEID='signContractPay_sdk';

delete from  hopesb.services   where name =  'cashierRecharge_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'cashierRecharge_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'cashierRecharge_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'cashierRecharge_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'cashierRecharge_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'package_out_flow_mchid' and location='local_out' and stype='SERVICE' and SERVICEID='cashierRecharge_napi';

delete from  hopesb.services   where name =  'cashierWithdraw_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'cashierWithdraw_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'cashierWithdraw_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'cashierWithdraw_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'cashierWithdraw_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_cashierWithdraw' and location='local_out' and stype='SERVICE' and SERVICEID='cashierWithdraw_napi';

delete from  hopesb.services   where name =  'orderPayment_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'orderPayment_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'orderPayment_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'orderPayment_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'orderPayment_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_orderPayment' and location='local_out' and stype='SERVICE' and SERVICEID='orderPayment_napi';

delete from  hopesb.services   where name =  'orderPayment_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'orderPayment_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'orderPayment_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'orderPayment_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'orderPayment_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_proxy_orderPayment' and location='local_out' and stype='SERVICE' and SERVICEID='orderPayment_sdk';

delete from  hopesb.services   where name =  'signResultNotice_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'signResultNotice_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'signResultNotice_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'signResultNotice_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'signResultNotice_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'through_out_flow_for_jx' and location='local_out' and stype='SERVICE' and SERVICEID='signResultNotice_napi';

delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "orderPre_secapi" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'orderPre_secapi';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'orderPre_secapi';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'orderPre_secapi';
DELETE from hopesb.BINDMAP where SERVICEID = 'orderPre_secapi';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'orderPre_secapi';
DELETE from hopesb.DEPLOYMENTS where NAME = 'orderPre_secapi';


delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "maintainSignInfo_sdk" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'maintainSignInfo_sdk';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'maintainSignInfo_sdk';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'maintainSignInfo_sdk';
DELETE from hopesb.BINDMAP where SERVICEID = 'maintainSignInfo_sdk';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'maintainSignInfo_sdk';
DELETE from hopesb.DEPLOYMENTS where NAME = 'maintainSignInfo_sdk';


delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "maintainSignInfo_napi" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'maintainSignInfo_napi';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'maintainSignInfo_napi';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'maintainSignInfo_napi';
DELETE from hopesb.BINDMAP where SERVICEID = 'maintainSignInfo_napi';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'maintainSignInfo_napi';
DELETE from hopesb.DEPLOYMENTS where NAME = 'maintainSignInfo_napi';


delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "bizOrderQuery_secapi" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'bizOrderQuery_secapi';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'bizOrderQuery_secapi';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'bizOrderQuery_secapi';
DELETE from hopesb.BINDMAP where SERVICEID = 'bizOrderQuery_secapi';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'bizOrderQuery_secapi';
DELETE from hopesb.DEPLOYMENTS where NAME = 'bizOrderQuery_secapi';


delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "bizOrderQuery_sdk" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'bizOrderQuery_sdk';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'bizOrderQuery_sdk';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'bizOrderQuery_sdk';
DELETE from hopesb.BINDMAP where SERVICEID = 'bizOrderQuery_sdk';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'bizOrderQuery_sdk';
DELETE from hopesb.DEPLOYMENTS where NAME = 'bizOrderQuery_sdk';


delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='payRecharge_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='checkPayPassWord_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='payWithdraw_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='queryAcctBlance_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='getTransactionList_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='queryAccountNo_sdk';

delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='rechargeSendMsg_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='querySignContract_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='signContractPayApply_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='signContractPay_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='orderPayment_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='orderPayment_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='signResultNotice_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='cashierRecharge_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='cashierWithdraw_napi';

delete from hopesb.ESB_ADAPTER_TEMPLATE where NAME = 'through_out_flow_for_jx';

delete from hopesb.dataadapter_param where DATAADAPTERID = 'through_out_flow_for_jx';

delete from hopesb.SERVICEINFO where SERVICEID = 'NoticePackageService';

delete from hopesb.BASESERVICES where SERVICEID = 'NoticePackageService';

delete from hopesb.SERVICEINFO where SERVICEID = 'ShrbDataEncryAndSignService';

delete from hopesb.BASESERVICES where SERVICEID = 'ShrbDataEncryAndSignService';
delete from hopesb.SERVICEINFO where SERVICEID = 'NoticeDataSignValidateAndDecryService';

delete from hopesb.BASESERVICES where SERVICEID = 'NoticeDataSignValidateAndDecryService';


delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='getH5Token_secapi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='approveDevV4_napi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='queryHopCustInfo_napi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='approveDevV4_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='permitEnterV2_napi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='eWalletPermitEnter_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='querySignInfo_napi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='queryEaccountAndSignState_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='querySignStateByMobile_secapi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='refund_secapi';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='queryOrderProdConf_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='queryJxAcctInfo_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where NAME='system_identify_rule' and RULENAME='queryBalanceByMobile_secapi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='commonVerifyFace_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='rmCardBindRelated_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='signContractPay_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='eAccountBalanceQueryCmpV2_napi';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_oauth_getH5Token';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_oauth_approveDevV4';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_cmp_queryHopCustInfo';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_proxy_approveDevV4';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_proxy_eWalletPermitEnter';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_cmp_querySignInfo';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_proxy_queryEaccountAndSignState';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_proxy_querySignStateByMobile';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_cmp_refund';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_cmp_queryOrderProdConf';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_cmp_queryJxAcctInfo';
delete from hopesb.PROTOCOLBIND where protocolid = 'http_out_proxy_queryBalanceByMobile';

delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_rmCardBindRelated_sdk';


delete from hopesb.SERVICES where NAME='getH5Token_secapi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='getH5Token_secapi';
delete from hopesb.SERVICEINFO where SERVICEID='getH5Token_secapi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='getH5Token_secapi' and STYPE='SERVICE' and PROTOCOLID='http_out_oauth_getH5Token' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='getH5Token_secapi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='getH5Token_secapi' and location='local_out';

delete from hopesb.SERVICES where NAME='approveDevV4_napi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='approveDevV4_napi';
delete from hopesb.SERVICEINFO where SERVICEID='approveDevV4_napi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='approveDevV4_napi' and STYPE='SERVICE' and PROTOCOLID='http_out_oauth_approveDevV4' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='approveDevV4_napi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='approveDevV4_napi' and location='local_out';

delete from hopesb.SERVICES where NAME='queryHopCustInfo_napi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='queryHopCustInfo_napi';
delete from hopesb.SERVICEINFO where SERVICEID='queryHopCustInfo_napi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='queryHopCustInfo_napi' and STYPE='SERVICE' and PROTOCOLID='http_out_cmp_queryHopCustInfo' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='queryHopCustInfo_napi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='queryHopCustInfo_napi' and location='local_out';

delete from hopesb.SERVICES where NAME='approveDevV4_sdk' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='approveDevV4_sdk';
delete from hopesb.SERVICEINFO where SERVICEID='approveDevV4_sdk' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='approveDevV4_sdk' and STYPE='SERVICE' and PROTOCOLID='http_out_proxy_approveDevV4' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='approveDevV4_sdk' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='approveDevV4_sdk' and location='local_out';

delete from hopesb.SERVICES where NAME='permitEnterV2_napi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='permitEnterV2_napi';
delete from hopesb.SERVICEINFO where SERVICEID='permitEnterV2_napi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='permitEnterV2_napi' and STYPE='SERVICE' and PROTOCOLID='http_out_cmp_permitEnter_napi' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='permitEnterV2_napi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='permitEnterV2_napi' and location='local_out';

delete from hopesb.SERVICES where NAME='eWalletPermitEnter_sdk' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='eWalletPermitEnter_sdk';
delete from hopesb.SERVICEINFO where SERVICEID='eWalletPermitEnter_sdk' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='eWalletPermitEnter_sdk' and STYPE='SERVICE' and PROTOCOLID='http_out_proxy_eWalletPermitEnter' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='eWalletPermitEnter_sdk' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='eWalletPermitEnter_sdk' and location='local_out';

delete from hopesb.SERVICES where NAME='querySignInfo_napi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='querySignInfo_napi';
delete from hopesb.SERVICEINFO where SERVICEID='querySignInfo_napi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='querySignInfo_napi' and STYPE='SERVICE' and PROTOCOLID='http_out_cmp_querySignInfo' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='querySignInfo_napi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='querySignInfo_napi' and location='local_out';

delete from hopesb.SERVICES where NAME='queryEaccountAndSignState_sdk' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='queryEaccountAndSignState_sdk';
delete from hopesb.SERVICEINFO where SERVICEID='queryEaccountAndSignState_sdk' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='queryEaccountAndSignState_sdk' and STYPE='SERVICE' and PROTOCOLID='http_out_proxy_queryEaccountAndSignState' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='queryEaccountAndSignState_sdk' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='queryEaccountAndSignState_sdk' and location='local_out';

delete from hopesb.SERVICES where NAME='querySignStateByMobile_secapi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='querySignStateByMobile_secapi';
delete from hopesb.SERVICEINFO where SERVICEID='querySignStateByMobile_secapi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='querySignStateByMobile_secapi' and STYPE='SERVICE' and PROTOCOLID='http_out_proxy_querySignStateByMobile' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='querySignStateByMobile_secapi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='querySignStateByMobile_secapi' and location='local_out';

delete from hopesb.SERVICES where NAME='refund_secapi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='refund_secapi';
delete from hopesb.SERVICEINFO where SERVICEID='refund_secapi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='refund_secapi' and STYPE='SERVICE' and PROTOCOLID='http_out_cmp_refund' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='refund_secapi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='refund_secapi' and location='local_out';

delete from hopesb.SERVICES where NAME='queryOrderProdConf_sdk' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='queryOrderProdConf_sdk';
delete from hopesb.SERVICEINFO where SERVICEID='queryOrderProdConf_sdk' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='queryOrderProdConf_sdk' and STYPE='SERVICE' and PROTOCOLID='http_out_cmp_queryOrderProdConf' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='queryOrderProdConf_sdk' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='queryOrderProdConf_sdk' and location='local_out';

delete from hopesb.SERVICES where NAME='queryJxAcctInfo_sdk' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='queryJxAcctInfo_sdk';
delete from hopesb.SERVICEINFO where SERVICEID='queryJxAcctInfo_sdk' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='queryJxAcctInfo_sdk' and STYPE='SERVICE' and PROTOCOLID='http_out_cmp_queryJxAcctInfo' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='queryJxAcctInfo_sdk' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='queryJxAcctInfo_sdk' and location='local_out';

delete from hopesb.SERVICES where NAME='queryBalanceByMobile_secapi' and location='local_out';
delete from hopesb.BUSSSERVICES where SERVICEID='queryBalanceByMobile_secapi';
delete from hopesb.SERVICEINFO where SERVICEID='queryBalanceByMobile_secapi' and location='local_out';
delete from hopesb.BINDMAP where SERVICEID='queryBalanceByMobile_secapi' and STYPE='SERVICE' and PROTOCOLID='http_out_proxy_queryBalanceByMobile' and location='local_out';
delete from hopesb.DATAADAPTER where DATAADAPTERID='queryBalanceByMobile_secapi' and location='local_out';
delete from hopesb.DEPLOYMENTS where NAME='queryBalanceByMobile_secapi' and location='local_out';

delete from  hopesb.services   where name =  'eAccountBalanceQueryCmpV2_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'eAccountBalanceQueryCmpV2_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'eAccountBalanceQueryCmpV2_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'eAccountBalanceQueryCmpV2_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'eAccountBalanceQueryCmpV2_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_balanceQuery' and location='local_out' and stype='SERVICE' and SERVICEID='eAccountBalanceQueryCmpV2_napi';


delete from  hopesb.services   where name =  'rmCardBindRelated_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'rmCardBindRelated_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'rmCardBindRelated_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'rmCardBindRelated_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'rmCardBindRelated_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_rmCardBindRelated_sdk' and location='local_out' and stype='SERVICE' and SERVICEID='rmCardBindRelated_sdk';

delete from  hopesb.services   where name =  'signContractPay_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'signContractPay_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'signContractPay_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'signContractPay_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'signContractPay_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_cmp_signContractPay' and location='local_out' and stype='SERVICE' and SERVICEID='signContractPay_napi';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_cmp_signContractPay';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_rmCardBindRelated_napi';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='rmCardBindRelated_napi';
# 回滚服务'rmCardBindRelated_napi'
delete from  hopesb.services   where name =  'rmCardBindRelated_napi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'rmCardBindRelated_napi' and location='local_out';
delete from  hopesb.deployments   where name =  'rmCardBindRelated_napi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'rmCardBindRelated_napi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'rmCardBindRelated_napi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_rmCardBindRelated_napi' and location='local_out' and stype='SERVICE' and SERVICEID='rmCardBindRelated_napi';


delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_queryAcctBindCardInfoList_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='queryAcctBindCardInfoList_sdk';
delete from  hopesb.services   where name =  'queryAcctBindCardInfoList_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'queryAcctBindCardInfoList_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'queryAcctBindCardInfoList_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'queryAcctBindCardInfoList_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'queryAcctBindCardInfoList_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_queryAcctBindCardInfoList_sdk' and location='local_out' and stype='SERVICE' and SERVICEID='queryAcctBindCardInfoList_sdk';


delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='queryOrderTransStatus_secapi';
delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_queryOrderTransStatus_secapi';

# 回滚服务'queryOrderTransStatus_secapi'
delete from  hopesb.services   where name =  'queryOrderTransStatus_secapi' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'queryOrderTransStatus_secapi' and location='local_out';
delete from  hopesb.deployments   where name =  'queryOrderTransStatus_secapi' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'queryOrderTransStatus_secapi' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'queryOrderTransStatus_secapi';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_queryOrderTransStatus_secapi' and location='local_out' and stype='SERVICE' and SERVICEID='queryOrderTransStatus_secapi';


delete from hopesb.PROTOCOLBIND where PROTOCOLID='http_out_queryOrderTransStatus_sdk';
delete from hopesb.ESB_IDENDIFY_RULES where name='system_identify_rule' and RULENAME='queryOrderTransStatus_sdk';

# 回滚服务'queryOrderTransStatus_sdk'
delete from  hopesb.services   where name =  'queryOrderTransStatus_sdk' and location='local_out';
delete from  hopesb.serviceinfo   where serviceid =  'queryOrderTransStatus_sdk' and location='local_out';
delete from  hopesb.deployments   where name =  'queryOrderTransStatus_sdk' and location='local_out';
delete from  hopesb.dataadapter   where dataadapterid =  'queryOrderTransStatus_sdk' and location='local_out';
delete from  hopesb.BUSSSERVICES   where serviceid =  'queryOrderTransStatus_sdk';
delete from  hopesb.bindmap   where PROTOCOLID =  'http_out_queryOrderTransStatus_sdk' and location='local_out' and stype='SERVICE' and SERVICEID='queryOrderTransStatus_sdk';

delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "maintainBankCardV2_napi" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'maintainBankCardV2_napi';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'maintainBankCardV2_napi';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'maintainBankCardV2_napi';
DELETE from hopesb.BINDMAP where SERVICEID = 'maintainBankCardV2_napi';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'maintainBankCardV2_napi';
DELETE from hopesb.DEPLOYMENTS where NAME = 'maintainBankCardV2_napi';

delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "bindCardSendMsgV2_napi" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'bindCardSendMsgV2_napi';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'bindCardSendMsgV2_napi';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'bindCardSendMsgV2_napi';
DELETE from hopesb.BINDMAP where SERVICEID = 'bindCardSendMsgV2_napi';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'bindCardSendMsgV2_napi';
DELETE from hopesb.DEPLOYMENTS where NAME = 'bindCardSendMsgV2_napi';

delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "maintainBankCardV2_sdk" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'maintainBankCardV2_sdk';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'maintainBankCardV2_sdk';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'maintainBankCardV2_sdk';
DELETE from hopesb.BINDMAP where SERVICEID = 'maintainBankCardV2_sdk';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'maintainBankCardV2_sdk';
DELETE from hopesb.DEPLOYMENTS where NAME = 'maintainBankCardV2_sdk';

delete from hopesb.ESB_IDENDIFY_RULES where RULENAME = "bindCardSendMsgV2_sdk" and SERVICEID = "CMP";
DELETE from hopesb.SERVICES where NAME = 'bindCardSendMsgV2_sdk';
DELETE from hopesb.BUSSSERVICES where SERVICEID = 'bindCardSendMsgV2_sdk';
DELETE from hopesb.SERVICEINFO where SERVICEID = 'bindCardSendMsgV2_sdk';
DELETE from hopesb.BINDMAP where SERVICEID = 'bindCardSendMsgV2_sdk';
DELETE from hopesb.DATAADAPTER where DATAADAPTERID = 'bindCardSendMsgV2_sdk';
DELETE from hopesb.DEPLOYMENTS where NAME = 'bindCardSendMsgV2_sdk';

DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_proxy_maintainBankCardV2';
DELETE from hopesb.PROTOCOLBIND where PROTOCOLID = 'http_out_proxy_bindCardSendMsgV2';

